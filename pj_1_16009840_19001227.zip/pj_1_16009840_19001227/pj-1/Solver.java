import java.util.ArrayList;
import java.io.File;
import java.util.LinkedList;
import java.util.Arrays;
import java.nio.file.Paths;
import java.nio.file.Files;
/*
    Esta es su clase principal. El unico metodo que debe implementar es
    public String[] solve(Maze maze)
    pero es libre de crear otros metodos y clases en este u otro archivo que desee.
*/
public class Solver{
	//
	int largo_total;
	int alto_total; 
	int cant_movimientos ;
	int num_salida;
	int num_entrada;

    public Solver(int largo, int alto, int movimientos, int salida, int entrada){
        largo_total = largo;
        alto_total = alto;
        cant_movimientos = movimientos;
        num_salida = salida;
        num_entrada = entrada;
    }



    public String[] solve(Maze maze){
        largo_total = maze.getWidth();
        alto_total = maze.getHeight();
        cant_movimientos = maze.getMaxMoves();
        num_salida = maze.getExitSpace();
        num_entrada = maze.getStartSpace();
        //Implemente su metodo aqui. Sientase libre de implementar métodos adicionales
        String[] resultado = new String[cant_movimientos];
        
        
        return resultado;
        
    }

}